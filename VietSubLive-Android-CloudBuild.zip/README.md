# VietSub Live — Android starter

Đây là **bản khung giao diện Android**, chưa phải ứng dụng dịch video hoàn chỉnh và chưa có APK đã biên dịch.

## Mở dự án
1. Cài Android Studio bản ổn định.
2. Giải nén thư mục `VietSubLive-Android`.
3. Android Studio → Open → chọn thư mục dự án.
4. Chờ Gradle Sync và cài Android SDK 35 nếu IDE yêu cầu.
5. Chạy trên máy Android hoặc emulator.

## Tạo APK thử nghiệm
Trong Android Studio: Build → Build Bundle(s) / APK(s) → Build APK(s).
APK debug thường nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## Tình trạng chức năng
- Có: giao diện nhập link, kiểm tra định dạng URL, công tắc phụ đề/lồng tiếng, khu vực video và bản dịch mẫu.
- Chưa có: phát video YouTube, lấy phụ đề/âm thanh, nhận diện giọng nói, dịch AI, TTS và đồng bộ thời gian.
- Không nhúng API key vào ứng dụng Android. Khi tích hợp API trả phí, cần backend giữ bí mật khóa và giới hạn chi phí.

## Kiến trúc dự kiến
Android app → backend HTTPS → speech-to-text → translation → text-to-speech → trả về các đoạn dịch có timestamp.

Lưu ý: việc lấy âm thanh/phụ đề từ video YouTube phải dùng nguồn và phương thức được YouTube cho phép. Không phải video nào cũng có phụ đề hoặc quyền truy cập âm thanh qua URL.
