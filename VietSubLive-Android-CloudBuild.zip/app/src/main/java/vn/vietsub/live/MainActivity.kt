package vn.vietsub.live

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF171923)
private val Panel = Color(0xFF252938)
private val Mint = Color(0xFF55D6BE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VietSubApp() }
    }
}

@Composable
fun VietSubApp() {
    var url by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Chưa có video") }
    var showSubtitles by remember { mutableStateOf(true) }
    var enableVoice by remember { mutableStateOf(true) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink,
            surface = Panel,
            primary = Mint,
            onPrimary = Ink,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🌐", fontSize = 28.sp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("VietSub Live", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("YouTube → Tiếng Việt", color = Color.LightGray, fontSize = 13.sp)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("ĐƯỜNG LINK YOUTUBE", color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = url,
                            onValueChange = { url = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Dán link YouTube tại đây") },
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                status = if (isYoutubeUrl(url)) {
                                    "Đã nhận link. Trình phát và bộ máy dịch sẽ được tích hợp ở bước tiếp theo."
                                } else {
                                    "Link chưa hợp lệ. Hãy nhập link youtube.com hoặc youtu.be."
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Kiểm tra video") }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("TRÌNH PHÁT VIDEO", color = Mint, fontWeight = FontWeight.Bold)
                        Box(
                            Modifier.fillMaxWidth().height(190.dp)
                                .background(Color(0xFF10131B), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("▶", color = Mint, fontSize = 38.sp)
                                Text("Khu vực video YouTube", color = Color.White)
                                Text("Chưa kết nối trình phát", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                        Text(status, color = Color.LightGray, fontSize = 13.sp)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CÀI ĐẶT BẢN DỊCH", color = Mint, fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Phụ đề tiếng Việt")
                                Text("Hiển thị nội dung đã dịch", color = Color.Gray, fontSize = 12.sp)
                            }
                            Switch(checked = showSubtitles, onCheckedChange = { showSubtitles = it })
                        }
                        HorizontalDivider(color = Color.DarkGray)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Lồng tiếng Việt")
                                Text("Đọc bản dịch bằng giọng nói", color = Color.Gray, fontSize = 12.sp)
                            }
                            Switch(checked = enableVoice, onCheckedChange = { enableVoice = it })
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("BẢN DỊCH", color = Mint, fontWeight = FontWeight.Bold)
                        Text(
                            "Bản dịch sẽ xuất hiện tại đây sau khi kết nối nhận diện giọng nói và dịch thuật.",
                            color = Color.LightGray
                        )
                        Text("Trạng thái: Chưa kết nối AI", color = Color(0xFFFFC76A), fontSize = 12.sp)
                    }
                }

                Text(
                    "VietSub Live 0.1.0 • Bản khung giao diện thử nghiệm",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}

private fun isYoutubeUrl(value: String): Boolean {
    val s = value.trim().lowercase()
    return (s.startsWith("https://") || s.startsWith("http://")) &&
        (s.contains("youtube.com/") || s.contains("youtu.be/"))
}
